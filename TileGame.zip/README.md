TileGame
========
An experimental tile-based game

Requires Python 2.7.5 and Pygame.
INSTALL.txt has installation instructions.

Generates a game world and lets you move a character with collision and turning.
Arrow keys to move. A summons a beetle minion at your feet that randomly roams around.
Press S to duplicate all beetles. Press W to remove all beetles.
Press and hold F to remove a tree/stump.
Press Insert to rebind all keys other than Insert

//ZeeQyu